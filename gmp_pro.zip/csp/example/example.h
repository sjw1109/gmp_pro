
// peripheral handle type

#ifndef _FILE_EXAMPLE_H_
#define _FILE_EXAMPLE_H_


#ifndef GMP_PHY_HANDLE_T
#define GMP_PHY_HANDLE_T void*
#endif

#ifndef GMP_IIC_HANDLE_T
#define GMP_IIC_HANDLE_T void*
#endif

#ifndef GMP_DATA_ELEMENT_T
#define GMP_DATA_ELEMENT_T char
#endif

#ifndef GMP_LENGTH_T
#define GMP_LENGTH_T uint32_t
#endif

#ifndef GMP_CMD_T
#define GMP_CMD_T uint32_t 
#endif

#endif // _FILE_EXAMPLE_H_
