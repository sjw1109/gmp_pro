# Chip Support Package

describe chip features

Unified device function name

The whole program main.c should include <global.h>.
This file contains all the C interface of GMP library.
That will not destroy your C

``` C++
#include <core/std/global.h>
```

If your project is a C++ project, and has main.cpp, you may directly include the <gmp_core.h>

``` C++
#include <core/gmp_core.hpp>
```

