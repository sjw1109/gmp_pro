
// invoke standard stm32 general header
#include <csp/stm32/stm32_general.h>
