
#include <csp/stm32/stm32_general.h>

// include stm32 C++ peripheral implementation
#include <csp/stm32/stm32_peri_impl.hpp>


