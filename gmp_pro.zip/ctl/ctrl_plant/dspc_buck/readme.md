# DSPC digital switching power controller for buck converter
