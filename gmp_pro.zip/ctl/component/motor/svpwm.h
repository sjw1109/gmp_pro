// Space Vector Pulse Width Modulation, SVPWM module

#ifndef _FILE_SVPWM_H_
#define _FILE_SVPWM_H_

inline void svpwm_gen(gmp_math_t** Vab, gmp_math_t** Tabc)
{

}


#endif
