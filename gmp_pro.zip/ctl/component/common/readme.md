# common blocks for controller
