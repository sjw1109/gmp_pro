#ifndef _FILE_LIMIT_SWITCH_H_
#define _FILE_LIMIT_SWITCH_H_



typedef struct _tag_limit_sw_t
{
	// fusing function

}limit_sw_t;


#endif // _FILE_LIMIT_SWITCH_H_

