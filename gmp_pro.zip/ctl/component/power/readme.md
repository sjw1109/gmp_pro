# digital power controller blocks
