// This file provide a set of function or utilities which must be implemented.

#ifndef _FILE_GMP_CPP_PORT_HPP
#define _FILE_GMP_CPP_PORT_HPP

// Global definitions of new and delete operator
// TODO impl




#endif // _FILE_GMP_CPP_PORT_HPP
