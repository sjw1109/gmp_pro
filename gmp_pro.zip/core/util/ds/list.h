
typedef struct _tag_gmp_list
{
	struct _tag_gmp_list* next;
}gmp_list;

