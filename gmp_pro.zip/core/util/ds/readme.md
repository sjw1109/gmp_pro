# Data structure

This folder contains common data structure.
