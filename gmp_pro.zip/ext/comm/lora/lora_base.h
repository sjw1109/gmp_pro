// This file provide a set of LoRa Communication operation.
// The performance of general LoRa device is like a Serial port.
// Some special LoRa device has a device ID and call the common mode as pass-through mode.


